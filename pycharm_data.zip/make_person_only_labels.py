import os

SPLIT_ROOT = os.path.join("data", "exdark_split")
OUTPUT_ROOT = os.path.join("data", "exdark_person_labels")

# In our original 12-class ordering, People is index 10
PEOPLE_CLASS_ID = 10


def main():
    total_files = 0
    total_boxes = 0

    for split_name in ("train", "val", "test"):
        src_labels_dir = os.path.join(SPLIT_ROOT, split_name, "labels")
        dst_labels_dir = os.path.join(OUTPUT_ROOT, split_name, "labels")
        os.makedirs(dst_labels_dir, exist_ok=True)

        for label_file in os.listdir(src_labels_dir):
            src_path = os.path.join(src_labels_dir, label_file)
            dst_path = os.path.join(dst_labels_dir, label_file)

            with open(src_path, "r") as f:
                lines = f.readlines()

            person_lines = []
            for line in lines:
                parts = line.strip().split()
                if len(parts) != 5:
                    continue
                class_id = int(parts[0])
                if class_id == PEOPLE_CLASS_ID:
                    # Remap to class 0 to match COCO's "person"
                    new_line = "0 " + " ".join(parts[1:])
                    person_lines.append(new_line)

            # Write the file even if empty (Ultralytics expects a label file
            # per image; an empty file means "no objects of interest")
            with open(dst_path, "w") as f:
                f.write("\n".join(person_lines))

            total_files += 1
            total_boxes += len(person_lines)

    print(f"Done. Processed {total_files} label files, kept {total_boxes} person boxes.")
    print(f"Output written to: {OUTPUT_ROOT}")


if __name__ == "__main__":
    main()