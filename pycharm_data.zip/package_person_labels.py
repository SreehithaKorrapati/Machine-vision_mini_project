import os
import zipfile

SRC_ROOT = os.path.join("data", "exdark_person_labels")
ZIP_OUTPUT_PATH = os.path.join("data", "exdark_person_labels_upload.zip")


def main():
    with zipfile.ZipFile(ZIP_OUTPUT_PATH, "w", zipfile.ZIP_DEFLATED) as zipf:
        file_count = 0
        for root, dirs, files in os.walk(SRC_ROOT):
            for file in files:
                full_path = os.path.join(root, file)
                arcname = os.path.relpath(full_path, "data")
                zipf.write(full_path, arcname=arcname)
                file_count += 1

    size_mb = os.path.getsize(ZIP_OUTPUT_PATH) / (1024 * 1024)
    print(f"Zipped {file_count} label files into {ZIP_OUTPUT_PATH} ({size_mb:.1f} MB)")


if __name__ == "__main__":
    main()