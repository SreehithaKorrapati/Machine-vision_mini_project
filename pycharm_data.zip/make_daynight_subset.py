import pandas as pd
import os

METADATA_CSV = os.path.join("data", "exdark_metadata.csv")
OUTPUT_DIR = "data"

VERY_DARK_LIGHTING = ["Low", "Ambient", "Object"]
LESS_DARK_LIGHTING = ["Screen", "Window", "Shadow", "Twilight"]


def main():
    df = pd.read_csv(METADATA_CSV)
    test_df = df[df["split"] == "test"]

    very_dark = test_df[test_df["lighting_name"].isin(VERY_DARK_LIGHTING)]
    less_dark = test_df[test_df["lighting_name"].isin(LESS_DARK_LIGHTING)]

    print(f"Test set total: {len(test_df)} images")
    print(f"Very dark subset (Low/Ambient/Object): {len(very_dark)} images")
    print(f"Less dark subset (Screen/Window/Shadow/Twilight): {len(less_dark)} images")

    very_dark_path = os.path.join(OUTPUT_DIR, "subset_very_dark_filenames.txt")
    less_dark_path = os.path.join(OUTPUT_DIR, "subset_less_dark_filenames.txt")

    with open(very_dark_path, "w") as f:
        f.write("\n".join(very_dark["filename"].tolist()))

    with open(less_dark_path, "w") as f:
        f.write("\n".join(less_dark["filename"].tolist()))

    print(f"\nWrote {very_dark_path}")
    print(f"Wrote {less_dark_path}")


if __name__ == "__main__":
    main()