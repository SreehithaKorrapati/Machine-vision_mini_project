import cv2
import os
import random


def apply_clahe(image, clip_limit=3.0, tile_grid_size=(8, 8)):

    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
    l_channel, a_channel, b_channel = cv2.split(lab)

    clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=tile_grid_size)
    l_enhanced = clahe.apply(l_channel)

    lab_enhanced = cv2.merge((l_enhanced, a_channel, b_channel))
    enhanced_bgr = cv2.cvtColor(lab_enhanced, cv2.COLOR_LAB2BGR)

    return enhanced_bgr


def visualize_clahe_samples(images_root, metadata_df, output_dir,
                             n_samples=6, clip_limit=2.0, tile_grid_size=(8, 8)):

    os.makedirs(output_dir, exist_ok=True)

    # Try to get a spread across different lighting conditions, not just random
    unique_lightings = metadata_df["lighting_name"].unique().tolist()
    random.shuffle(unique_lightings)

    chosen_rows = []
    for lighting in unique_lightings:
        subset = metadata_df[metadata_df["lighting_name"] == lighting]
        if len(subset) == 0:
            continue
        chosen_rows.append(subset.sample(1).iloc[0])
        if len(chosen_rows) >= n_samples:
            break

    for i, row in enumerate(chosen_rows):
        img_path = os.path.join(images_root, row["class_name"], row["filename"])
        if not os.path.exists(img_path):
            print(f"[SKIP] Missing image: {img_path}")
            continue

        original = cv2.imread(img_path)
        enhanced = apply_clahe(original, clip_limit, tile_grid_size)

        h, w = original.shape[:2]
        combined = cv2.hconcat([original, enhanced])

        cv2.putText(combined, "Original", (10, 30), cv2.FONT_HERSHEY_SIMPLEX,
                    1.0, (0, 255, 0), 2)
        cv2.putText(combined, "CLAHE Enhanced", (w + 10, 30), cv2.FONT_HERSHEY_SIMPLEX,
                    1.0, (0, 255, 0), 2)

        out_name = f"clahe_compare_{i+1}_{row['lighting_name']}.jpg"
        out_path = os.path.join(output_dir, out_name)
        cv2.imwrite(out_path, combined)
        print(f"[OK] Saved: {out_path} (lighting: {row['lighting_name']}, class: {row['class_name']})")


if __name__ == "__main__":
    import pandas as pd

    IMAGES_ROOT = os.path.join("data", "exdark_images", "ExDark")
    METADATA_CSV = os.path.join("data", "exdark_metadata.csv")
    OUTPUT_DIR = os.path.join("data", "clahe_samples")

    df = pd.read_csv(METADATA_CSV)
    visualize_clahe_samples(IMAGES_ROOT, df, OUTPUT_DIR, n_samples=6)

    print("\nDone. Open the images in data/clahe_samples/ to inspect the before/after effect.")