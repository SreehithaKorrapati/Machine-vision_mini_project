import os
import cv2

IMAGES_ROOT = os.path.join("data", "exdark_images", "ExDark")
LABELS_ROOT = os.path.join("data", "exdark_yolo_labels")
OUTPUT_DIR = os.path.join("data", "verification_samples")

CLASS_NAMES = [
    "Bicycle", "Boat", "Bottle", "Bus", "Car", "Cat",
    "Chair", "Cup", "Dog", "Motorbike", "People", "Table"
]

# Pick a few (class_name, filename_without_extension) samples to check.
# Feel free to add more tuples here.
SAMPLES_TO_CHECK = [
    ("People", "2015_06246"),
]


def draw_boxes_on_image(class_name, base_name):
    # Find the actual image file (could be .jpg or .png)
    img_dir = os.path.join(IMAGES_ROOT, class_name)
    img_path = None
    for ext in (".jpg", ".jpeg", ".png"):
        candidate = os.path.join(img_dir, base_name + ext)
        if os.path.exists(candidate):
            img_path = candidate
            break

    if img_path is None:
        print(f"[SKIP] No image found for {class_name}/{base_name}")
        return

    label_path = os.path.join(LABELS_ROOT, class_name, base_name + ".txt")
    if not os.path.exists(label_path):
        print(f"[SKIP] No label found for {class_name}/{base_name}")
        return

    img = cv2.imread(img_path)
    img_h, img_w = img.shape[:2]

    with open(label_path, "r") as f:
        lines = f.readlines()

    for line in lines:
        parts = line.strip().split()
        if len(parts) != 5:
            continue
        class_id, x_c, y_c, w, h = parts
        class_id = int(class_id)
        x_c, y_c, w, h = map(float, (x_c, y_c, w, h))

        # Convert normalized center-based coords back to pixel corner coords
        box_w = w * img_w
        box_h = h * img_h
        x1 = int((x_c * img_w) - box_w / 2)
        y1 = int((y_c * img_h) - box_h / 2)
        x2 = int(x1 + box_w)
        y2 = int(y1 + box_h)

        label_text = CLASS_NAMES[class_id]
        cv2.rectangle(img, (x1, y1), (x2, y2), (0, 255, 0), 2)
        cv2.putText(img, label_text, (x1, max(y1 - 5, 10)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    out_path = os.path.join(OUTPUT_DIR, f"{class_name}_{base_name}_check.jpg")
    cv2.imwrite(out_path, img)
    print(f"[OK] Saved: {out_path}")


def main():
    for class_name, base_name in SAMPLES_TO_CHECK:
        draw_boxes_on_image(class_name, base_name)


if __name__ == "__main__":
    main()