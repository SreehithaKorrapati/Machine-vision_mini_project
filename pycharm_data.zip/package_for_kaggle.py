import os
import zipfile

SPLIT_ROOT = os.path.join("data", "exdark_split")
YAML_PATH = os.path.join("data", "data.yaml")
ZIP_OUTPUT_PATH = os.path.join("data", "exdark_kaggle_upload.zip")

# Same 12-class order used in convert_to_yolo.py -- MUST match exactly,
# since class IDs in the label files depend on this order.
CLASS_NAMES = [
    "Bicycle", "Boat", "Bottle", "Bus", "Car", "Cat",
    "Chair", "Cup", "Dog", "Motorbike", "People", "Table"
]


def write_data_yaml():

    yaml_content = "train: exdark_split/train/images\n"
    yaml_content += "val: exdark_split/val/images\n"
    yaml_content += "test: exdark_split/test/images\n"
    yaml_content += f"nc: {len(CLASS_NAMES)}\n"
    yaml_content += "names:\n"
    for idx, name in enumerate(CLASS_NAMES):
        yaml_content += f"  {idx}: {name}\n"

    with open(YAML_PATH, "w") as f:
        f.write(yaml_content)

    print(f"[OK] Wrote {YAML_PATH}")


def zip_dataset():
    print(f"Zipping dataset -- this may take a few minutes (dataset is ~1.5GB)...")

    with zipfile.ZipFile(ZIP_OUTPUT_PATH, "w", zipfile.ZIP_DEFLATED) as zipf:
        # Add data.yaml at the root
        zipf.write(YAML_PATH, arcname="data.yaml")

        # Add all train/val/test images and labels
        file_count = 0
        for root, dirs, files in os.walk(SPLIT_ROOT):
            for file in files:
                full_path = os.path.join(root, file)
                # arcname preserves the exdark_split/... structure inside the zip
                arcname = os.path.relpath(full_path, "data")
                zipf.write(full_path, arcname=arcname)
                file_count += 1
                if file_count % 2000 == 0:
                    print(f"  ...{file_count} files zipped so far")

    print(f"[OK] Zipped {file_count} files into {ZIP_OUTPUT_PATH}")


def main():
    write_data_yaml()
    zip_dataset()

    size_mb = os.path.getsize(ZIP_OUTPUT_PATH) / (1024 * 1024)
    print("\n" + "=" * 50)
    print(f"Done. Upload this file to Kaggle: {ZIP_OUTPUT_PATH}")
    print(f"Zip size: {size_mb:.1f} MB")
    print("=" * 50)


if __name__ == "__main__":
    main()