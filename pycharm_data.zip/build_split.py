import os
import csv
import shutil

IMAGECLASSLIST_PATH = os.path.join(
    "data", "Exclusively-Dark-Image-Dataset", "Groundtruth", "imageclasslist.txt"
)
IMAGES_ROOT = os.path.join("data", "exdark_images", "ExDark")
LABELS_ROOT = os.path.join("data", "exdark_yolo_labels")
SPLIT_ROOT = os.path.join("data", "exdark_split")
METADATA_CSV = os.path.join("data", "exdark_metadata.csv")

# Column 2 mapping: Bicycle(1) ... Table(12)
CLASS_ID_TO_NAME = {
    1: "Bicycle", 2: "Boat", 3: "Bottle", 4: "Bus", 5: "Car", 6: "Cat",
    7: "Chair", 8: "Cup", 9: "Dog", 10: "Motorbike", 11: "People", 12: "Table"
}

# Column 3 mapping: lighting type
LIGHTING_ID_TO_NAME = {
    1: "Low", 2: "Ambient", 3: "Object", 4: "Single", 5: "Weak",
    6: "Strong", 7: "Screen", 8: "Window", 9: "Shadow", 10: "Twilight"
}

# Column 4 mapping
INOUT_ID_TO_NAME = {1: "Indoor", 2: "Outdoor"}

# Column 5 mapping
SPLIT_ID_TO_NAME = {1: "train", 2: "val", 3: "test"}


def ensure_split_dirs():
    for split_name in ("train", "val", "test"):
        os.makedirs(os.path.join(SPLIT_ROOT, split_name, "images"), exist_ok=True)
        os.makedirs(os.path.join(SPLIT_ROOT, split_name, "labels"), exist_ok=True)


def main():
    ensure_split_dirs()

    rows_written = 0
    copied = 0
    skipped = 0

    with open(IMAGECLASSLIST_PATH, "r") as f, open(METADATA_CSV, "w", newline="") as csv_out:
        writer = csv.writer(csv_out)
        writer.writerow([
            "filename", "class_name", "class_id", "lighting_id", "lighting_name",
            "indoor_outdoor", "split"
        ])

        lines = f.readlines()
        # First line is the header ("Name | Class | Light | In/Out | Train/Val/Test") — skip it
        for line in lines[1:]:
            parts = line.strip().split()
            if len(parts) != 5:
                continue  # skip malformed/blank lines

            filename, class_id, lighting_id, inout_id, split_id = parts
            class_id = int(class_id)
            lighting_id = int(lighting_id)
            inout_id = int(inout_id)
            split_id = int(split_id)

            class_name = CLASS_ID_TO_NAME.get(class_id)
            lighting_name = LIGHTING_ID_TO_NAME.get(lighting_id, "Unknown")
            inout_name = INOUT_ID_TO_NAME.get(inout_id, "Unknown")
            split_name = SPLIT_ID_TO_NAME.get(split_id)

            if class_name is None or split_name is None:
                print(f"[WARN] Unrecognized class/split id for {filename}, skipping")
                skipped += 1
                continue

            # Source paths
            src_img_path = os.path.join(IMAGES_ROOT, class_name, filename)
            base_name = os.path.splitext(filename)[0]
            src_label_path = os.path.join(LABELS_ROOT, class_name, base_name + ".txt")

            if not os.path.exists(src_img_path):
                print(f"[SKIP] Missing image: {src_img_path}")
                skipped += 1
                continue
            if not os.path.exists(src_label_path):
                print(f"[SKIP] Missing label: {src_label_path}")
                skipped += 1
                continue

            # Destination paths
            dst_img_path = os.path.join(SPLIT_ROOT, split_name, "images", filename)
            dst_label_path = os.path.join(SPLIT_ROOT, split_name, "labels", base_name + ".txt")

            shutil.copy2(src_img_path, dst_img_path)
            shutil.copy2(src_label_path, dst_label_path)
            copied += 1

            writer.writerow([
                filename, class_name, class_id, lighting_id, lighting_name,
                inout_name, split_name
            ])
            rows_written += 1

    print("\n" + "=" * 50)
    print(f"Done. Copied {copied} image/label pairs into {SPLIT_ROOT}")
    print(f"Metadata CSV written: {METADATA_CSV} ({rows_written} rows)")
    print(f"Skipped: {skipped}")


if __name__ == "__main__":
    main()