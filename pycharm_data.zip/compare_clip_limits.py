import os
import cv2
import pandas as pd
from clahe_module import apply_clahe

IMAGES_ROOT = os.path.join("data", "exdark_images", "ExDark")
METADATA_CSV = os.path.join("data", "exdark_metadata.csv")
OUTPUT_DIR = os.path.join("data", "clahe_clip_comparison")

# Target the darkest lighting conditions specifically
TARGET_LIGHTINGS = ["Low", "Shadow"]
CLIP_LIMITS_TO_TEST = [2.0, 3.0, 4.0]


def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    df = pd.read_csv(METADATA_CSV)

    for lighting in TARGET_LIGHTINGS:
        subset = df[df["lighting_name"] == lighting]
        if len(subset) == 0:
            print(f"[SKIP] No images found for lighting: {lighting}")
            continue

        row = subset.sample(1).iloc[0]
        img_path = os.path.join(IMAGES_ROOT, row["class_name"], row["filename"])

        if not os.path.exists(img_path):
            print(f"[SKIP] Missing image: {img_path}")
            continue

        original = cv2.imread(img_path)
        panels = [original]
        labels = ["Original"]

        for clip in CLIP_LIMITS_TO_TEST:
            enhanced = apply_clahe(original, clip_limit=clip, tile_grid_size=(8, 8))
            panels.append(enhanced)
            labels.append(f"clip={clip}")

        combined = cv2.hconcat(panels)

        # Add labels above each panel
        panel_width = original.shape[1]
        for i, label in enumerate(labels):
            x_pos = i * panel_width + 10
            cv2.putText(combined, label, (x_pos, 30), cv2.FONT_HERSHEY_SIMPLEX,
                        0.9, (0, 255, 0), 2)

        out_name = f"clip_comparison_{lighting}_{row['filename']}.jpg"
        out_path = os.path.join(OUTPUT_DIR, out_name)
        cv2.imwrite(out_path, combined)
        print(f"[OK] Saved: {out_path} (lighting: {lighting}, class: {row['class_name']})")

    print(f"\nDone. Open images in {OUTPUT_DIR} to compare clip limits side by side.")


if __name__ == "__main__":
    main()