import os
import pandas as pd
import matplotlib.pyplot as plt

METADATA_CSV = os.path.join("data", "exdark_metadata.csv")
SPLIT_ROOT = os.path.join("data", "exdark_split")
OUTPUT_DIR = os.path.join("data", "eda_outputs")

os.makedirs(OUTPUT_DIR, exist_ok=True)


def save_bar_plot(series, title, xlabel, filename, rotate=45):
    plt.figure(figsize=(9, 5))
    series.plot(kind="bar", color="#4C72B0")
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel("Count")
    plt.xticks(rotation=rotate, ha="right")
    plt.tight_layout()
    out_path = os.path.join(OUTPUT_DIR, filename)
    plt.savefig(out_path, dpi=150)
    plt.close()
    print(f"[Saved] {out_path}")


def main():
    df = pd.read_csv(METADATA_CSV)

    print("=" * 60)
    print("1. CLASS DISTRIBUTION (all images)")
    print("=" * 60)
    class_counts = df["class_name"].value_counts()
    print(class_counts)
    save_bar_plot(class_counts, "Class Distribution", "Class", "class_distribution.png")

    print("\n" + "=" * 60)
    print("2. LIGHTING CONDITION DISTRIBUTION (all images)")
    print("=" * 60)
    lighting_counts = df["lighting_name"].value_counts()
    print(lighting_counts)
    save_bar_plot(lighting_counts, "Lighting Condition Distribution", "Lighting Type", "lighting_distribution.png")

    print("\n" + "=" * 60)
    print("3. INDOOR vs OUTDOOR DISTRIBUTION")
    print("=" * 60)
    inout_counts = df["indoor_outdoor"].value_counts()
    print(inout_counts)
    save_bar_plot(inout_counts, "Indoor vs Outdoor", "Type", "indoor_outdoor_distribution.png")

    print("\n" + "=" * 60)
    print("4. LIGHTING CONDITION BREAKDOWN -- PEOPLE CLASS ONLY")
    print("=" * 60)
    people_df = df[df["class_name"] == "People"]
    people_lighting = people_df["lighting_name"].value_counts()
    print(people_lighting)
    save_bar_plot(people_lighting, "People Class -- Lighting Breakdown", "Lighting Type", "people_lighting_distribution.png")

    print("\n" + "=" * 60)
    print("5. CLASS DISTRIBUTION PER SPLIT (train/val/test)")
    print("=" * 60)
    split_class = df.groupby(["split", "class_name"]).size().unstack(fill_value=0)
    print(split_class)
    split_class.to_csv(os.path.join(OUTPUT_DIR, "class_distribution_per_split.csv"))
    print(f"[Saved] {os.path.join(OUTPUT_DIR, 'class_distribution_per_split.csv')}")

    print("\n" + "=" * 60)
    print("6. PEDESTRIAN (PEOPLE) BOUNDING BOX SIZE STATS")
    print("=" * 60)
    box_widths = []
    box_heights = []
    box_areas = []

    for split_name in ("train", "val", "test"):
        labels_dir = os.path.join(SPLIT_ROOT, split_name, "labels")
        if not os.path.isdir(labels_dir):
            continue
        for label_file in os.listdir(labels_dir):
            label_path = os.path.join(labels_dir, label_file)
            with open(label_path, "r") as f:
                for line in f:
                    parts = line.strip().split()
                    if len(parts) != 5:
                        continue
                    class_id = int(parts[0])
                    if class_id != 10:  # 10 = People (0-indexed, see CLASS_NAMES order)
                        continue
                    _, _, _, w, h = parts
                    w, h = float(w), float(h)
                    box_widths.append(w)
                    box_heights.append(h)
                    box_areas.append(w * h)

    box_stats_df = pd.DataFrame({
        "width_norm": box_widths,
        "height_norm": box_heights,
        "area_norm": box_areas
    })
    print(box_stats_df.describe())
    box_stats_df.to_csv(os.path.join(OUTPUT_DIR, "people_box_stats.csv"), index=False)
    print(f"[Saved] {os.path.join(OUTPUT_DIR, 'people_box_stats.csv')}")

    # Histogram of pedestrian box areas (normalized) -- shows how many are small/large
    plt.figure(figsize=(9, 5))
    plt.hist(box_areas, bins=40, color="#55A868")
    plt.title("Pedestrian Bounding Box Area Distribution (normalized)")
    plt.xlabel("Box area (fraction of image area)")
    plt.ylabel("Count")
    plt.tight_layout()
    out_path = os.path.join(OUTPUT_DIR, "people_box_area_histogram.png")
    plt.savefig(out_path, dpi=150)
    plt.close()
    print(f"[Saved] {out_path}")

    print("\n" + "=" * 60)
    print(f"EDA complete. All outputs saved to: {OUTPUT_DIR}")
    print("=" * 60)


if __name__ == "__main__":
    main()