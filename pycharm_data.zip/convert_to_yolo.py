import os
import cv2

# ---- CONFIG ----
IMAGES_ROOT = os.path.join("data", "exdark_images", "ExDark")
ANNOTATIONS_ROOT = os.path.join("data", "exdark_groundtruth", "ExDark_Annno")
OUTPUT_ROOT = os.path.join("data", "exdark_yolo_labels")

# Class name -> YOLO class id (0-indexed), fixed order so it's reproducible
CLASS_NAMES = [
    "Bicycle", "Boat", "Bottle", "Bus", "Car", "Cat",
    "Chair", "Cup", "Dog", "Motorbike", "People", "Table"
]
CLASS_TO_ID = {name: idx for idx, name in enumerate(CLASS_NAMES)}


def convert_one_annotation(ann_path, image_path):
    """Read one ExDark annotation file + its matching image, return list of YOLO-format lines."""
    img = cv2.imread(image_path)
    if img is None:
        print(f"  [SKIP] Could not read image: {image_path}")
        return None

    img_h, img_w = img.shape[:2]

    yolo_lines = []
    with open(ann_path, "r") as f:
        lines = f.readlines()

    # First line is always the '% bbGt version=3' header — skip it
    for line in lines[1:]:
        parts = line.strip().split()
        if len(parts) < 5:
            continue  # blank or malformed line

        class_name = parts[0]
        if class_name not in CLASS_TO_ID:
            print(f"  [WARN] Unknown class '{class_name}' in {ann_path}, skipping this box")
            continue

        left, top, width, height = map(float, parts[1:5])

        # Convert [left, top, width, height] (pixels, top-left origin)
        # to [x_center, y_center, width, height] (normalized 0-1, center origin)
        x_center = (left + width / 2) / img_w
        y_center = (top + height / 2) / img_h
        norm_w = width / img_w
        norm_h = height / img_h

        # Clip to [0, 1] in case of any annotation edge-case overflow
        x_center = min(max(x_center, 0), 1)
        y_center = min(max(y_center, 0), 1)
        norm_w = min(max(norm_w, 0), 1)
        norm_h = min(max(norm_h, 0), 1)

        class_id = CLASS_TO_ID[class_name]
        yolo_lines.append(f"{class_id} {x_center:.6f} {y_center:.6f} {norm_w:.6f} {norm_h:.6f}")

    return yolo_lines


def main():
    total_images = 0
    total_boxes = 0
    skipped = 0

    for class_name in CLASS_NAMES:
        img_dir = os.path.join(IMAGES_ROOT, class_name)
        ann_dir = os.path.join(ANNOTATIONS_ROOT, class_name)
        out_dir = os.path.join(OUTPUT_ROOT, class_name)

        if not os.path.isdir(img_dir) or not os.path.isdir(ann_dir):
            print(f"[WARN] Missing folder for class '{class_name}', skipping")
            continue

        os.makedirs(out_dir, exist_ok=True)

        image_files = [f for f in os.listdir(img_dir) if f.lower().endswith((".jpg", ".png", ".jpeg"))]
        print(f"\n[{class_name}] {len(image_files)} images found")

        for img_filename in image_files:
            ann_filename = img_filename + ".txt"  # e.g. 2015_06246.jpg -> 2015_06246.jpg.txt
            ann_path = os.path.join(ann_dir, ann_filename)
            img_path = os.path.join(img_dir, img_filename)

            if not os.path.exists(ann_path):
                print(f"  [SKIP] No annotation found for {img_filename}")
                skipped += 1
                continue

            yolo_lines = convert_one_annotation(ann_path, img_path)
            if yolo_lines is None:
                skipped += 1
                continue

            # Output label filename: strip original extension, add .txt
            # e.g. 2015_06246.jpg -> 2015_06246.txt
            base_name = os.path.splitext(img_filename)[0]
            out_path = os.path.join(out_dir, base_name + ".txt")

            with open(out_path, "w") as f:
                f.write("\n".join(yolo_lines))

            total_images += 1
            total_boxes += len(yolo_lines)

    print("\n" + "=" * 50)
    print(f"Done. Converted {total_images} images, {total_boxes} bounding boxes.")
    print(f"Skipped {skipped} images (missing annotation or unreadable image).")
    print(f"YOLO labels written to: {OUTPUT_ROOT}")


if __name__ == "__main__":
    main()