import cv2
import albumentations as A
import os
import random


def _bilateral_filter(image, **kwargs):

    return cv2.bilateralFilter(image, d=9, sigmaColor=75, sigmaSpace=75)


def build_augmentation_pipeline(p_gamma=0.5, p_noise=0.5, p_motion_blur=0.4, p_bilateral=0.3):

    pipeline = A.Compose([
        A.RandomGamma(gamma_limit=(130, 200), p=p_gamma),
        A.GaussNoise(std_range=(0.04, 0.12), p=p_noise),
        A.MotionBlur(blur_limit=(3, 7), p=p_motion_blur),
        A.Lambda(image=_bilateral_filter, p=p_bilateral),
    ])

    return pipeline


def visualize_augmentation_samples(images_root, metadata_df, output_dir, n_samples=6, seed=None):

    if seed is not None:
        random.seed(seed)

    os.makedirs(output_dir, exist_ok=True)
    pipeline = build_augmentation_pipeline(
        p_gamma=1.0, p_noise=1.0, p_motion_blur=1.0, p_bilateral=1.0
    )  # force all 4 effects "on" for visualization purposes, so each demo image shows the full combined effect

    # Sample from relatively well-lit conditions to show the "darkening" effect clearly
    candidates = metadata_df[metadata_df["lighting_name"].isin(["Ambient", "Strong", "Single"])]
    if len(candidates) == 0:
        candidates = metadata_df

    chosen_rows = candidates.sample(min(n_samples, len(candidates)))

    for i, (_, row) in enumerate(chosen_rows.iterrows()):
        img_path = os.path.join(images_root, row["class_name"], row["filename"])
        if not os.path.exists(img_path):
            print(f"[SKIP] Missing image: {img_path}")
            continue

        original = cv2.imread(img_path)
        augmented = pipeline(image=original)["image"]

        combined = cv2.hconcat([original, augmented])
        w = original.shape[1]
        cv2.putText(combined, "Original", (10, 30), cv2.FONT_HERSHEY_SIMPLEX,
                    1.0, (0, 255, 0), 2)
        cv2.putText(combined, "Augmented (night-sim)", (w + 10, 30), cv2.FONT_HERSHEY_SIMPLEX,
                    1.0, (0, 255, 0), 2)

        out_name = f"aug_compare_{i+1}_{row['lighting_name']}.jpg"
        out_path = os.path.join(output_dir, out_name)
        cv2.imwrite(out_path, combined)
        print(f"[OK] Saved: {out_path} (original lighting: {row['lighting_name']}, class: {row['class_name']})")


if __name__ == "__main__":
    import pandas as pd

    IMAGES_ROOT = os.path.join("data", "exdark_images", "ExDark")
    METADATA_CSV = os.path.join("data", "exdark_metadata.csv")
    OUTPUT_DIR = os.path.join("data", "augmentation_samples")

    df = pd.read_csv(METADATA_CSV)
    visualize_augmentation_samples(IMAGES_ROOT, df, OUTPUT_DIR, n_samples=6, seed=42)

    print("\nDone. Open the images in data/augmentation_samples/ to inspect the effect.")